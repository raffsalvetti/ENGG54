/*
 * oled_test.h
 *
 *  Created on: 14 de set de 2019
 *      Author: root
 */

#ifndef OLED_TEST_H_
#define OLED_TEST_H_
#endif /* OLED_TEST_H_ */

#include"ezdsp5502.h"
#include"lcd.h"


Int16 oled_test();

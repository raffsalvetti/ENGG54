//////////////////////////////////////////////////////////////////////////////
// * File name: lcd.c
// *                                                                          
// * Description:  LCD functions.
// *                                                                          
// * Copyright (C) 2011 Texas Instruments Incorporated - http://www.ti.com/ 
// * Copyright (C) 2011 Spectrum Digital, Incorporated
// *                                                                          
// *                                                                          
// *  Redistribution and use in source and binary forms, with or without      
// *  modification, are permitted provided that the following conditions      
// *  are met:                                                                
// *                                                                          
// *    Redistributions of source code must retain the above copyright        
// *    notice, this list of conditions and the following disclaimer.         
// *                                                                          
// *    Redistributions in binary form must reproduce the above copyright     
// *    notice, this list of conditions and the following disclaimer in the   
// *    documentation and/or other materials provided with the                
// *    distribution.                                                         
// *                                                                          
// *    Neither the name of Texas Instruments Incorporated nor the names of   
// *    its contributors may be used to endorse or promote products derived   
// *    from this software without specific prior written permission.         
// *                                                                          
// *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS     
// *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       
// *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR   
// *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT    
// *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,   
// *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT        
// *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,   
// *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY   
// *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT     
// *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE   
// *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.    
// *                                                                          
//////////////////////////////////////////////////////////////////////////////
 
#include"ezdsp5502_i2c.h"
#include"ezdsp5502_gpio.h"
#include "csl_gpio.h"
#include"lcd.h"


#define OSD9616_I2C_ADDR 0x3C    // OSD9616 OLED Display I2C address

/*
 *
 *  Int16 OSD9616_init( )
 *
 *      Initialize LCD display
 *
 */
Int16 osd9616_init( )
{
    Uint16 cmd[10];    // For multibyte commands
    
    /* Initialize LCD power */
    EZDSP5502_GPIO_init( GPIO_GPIO_PIN1 );         // Enable GPIO pin
    EZDSP5502_GPIO_setDirection( GPIO_GPIO_PIN1, GPIO_GPIO_PIN1_OUTPUT );  // Output
    EZDSP5502_GPIO_setOutput( GPIO_GPIO_PIN1, 1 ); // Enable 13V



    osd9616_send(0x00, 0x2E); //Deactivate scroll;

    // Initialize osd9616 display


    cmd[0] = 0x00 & 0x00FF;     //comando
    //cmd[0] = 0x00;
    cmd[1] = 0x20;      //alterar modo de endereçamento da imagem
    cmd[2] = 0x00 & 0x00FF;      //setar modo horizontal
    osd9616_multiSend(cmd,3);


    //Comando para setar coluna de início e de fim;
    cmd[0]=0x00 & 0x00FF; //Evitar bug de preenchimento
    //cmd[0] = 0x00;
    cmd[1] = 0x21;
    //cmd[2] = 0x00 & 0x00FF;
    cmd[2] = 0x0020; //Começa na coluna 32
    cmd[3] = 0x7F;
    osd9616_multiSend(cmd,4); //setar coluna de inicio do modo horizontal




    //Setar páginas inicial e final para modo horizontal;
    //cmd[0] = 0x00 & 0x00FF;
    cmd[0] = 0x00;
    cmd[1] = 0x22;
    cmd[2] = 0x00;
    cmd[3] = 0x01;
    osd9616_multiSend(cmd,4);

    osd9616_send(0x00,0x40); //Display start line

    // Set contrast control register
    //cmd[0] = 0x00 & 0x00FF;
    cmd[0] = 0x00;
    cmd[1] = 0x81;
    cmd[2] = 0x7f;
    osd9616_multiSend( cmd, 3 ); //Envia configuração do display(contraste)

    osd9616_send(0x00,0xa0); // Set segment re-map SEG0 to 0
    osd9616_send(0x00,0xa6); // Set normal display


    //Alterar para modo piscante
    cmd[0] = 0x0000;
    cmd[1] = 0x23;
    cmd[2] = 0x30;
    osd9616_multiSend(cmd, 3);

    // Set multiplex ratio(1 to 16)
    cmd[0] = 0x00 & 0x00FF;
    //cmd[0] = 0x0000;
    cmd[1] = 0xa8; 
    cmd[2] = 0x0f;
    osd9616_multiSend( cmd, 3 );


     //Altera o offset de coluna para 0 (não há offset)
    osd9616_send(0x00,0xd3); // Request display offset change and the new value (both send commands)
    osd9616_send(0x00,0x00); // -> new offset value

    //Altera a razão de clock para o valor máximo
    osd9616_send(0x00,0xD5); // Request display clock divide ratio/oscillator frequency change,
    osd9616_send(0x00,0xF0); // in this case, using maximum frequency allowed by the display;



    // Set pre-charge period

    cmd[0] = 0x00 & 0x00FF;
    //cmd[0] = 0x00;
    cmd[1] = 0xd9;
    cmd[2] = 0x22;
    osd9616_multiSend( cmd, 3 );


    // Set com pins hardware configuration
    cmd[0] = 0x00 & 0x00FF;
    //cmd[0] = 0x00;
    cmd[1] = 0xda;
    cmd[2] = 0x02;
    osd9616_multiSend( cmd, 3 );

    osd9616_send(0x00,0xdb); // Set vcomh
    osd9616_send(0x00,0x49); // 0.83*vref


    // set DC-DC enable
    cmd[0] = 0x00 & 0x00FF;
    cmd[1] = 0x8d;   //Request for Charge-pump option
    cmd[2] = 0x14; //Enables Charge pump (DC-DC Converter)
    osd9616_multiSend( cmd, 3 );


    osd9616_send(0x00,0xAF); // Turn on oled panel
    
    return 0;
}

/*
 *
 *  Int16 osd9616_send( Uint16 comdat, Uint16 data )
 *
 *      Sends 2 bytes of data to the osd9616
 *
 */
Int16 osd9616_send( Uint16 comdat, Uint16 data )
{
    Uint16 cmd[2];
    cmd[0] = comdat & 0x00FF;     // Specifies whether data is Command or Data
    cmd[1] = data;                // Command / Data

    /* Write to OSD9616 */
    return EZDSP5502_I2C_write( OSD9616_I2C_ADDR, cmd, 2 );
}
/*
 *
 *  Int16 osd9616_multiSend( Uint16 comdat, Uint16 data )
 *
 *      Sends multiple bytes of data to the osd9616
 *
 */
Int16 osd9616_multiSend( Uint16* data, Uint16 len )
{
    Uint16 x;
    Uint16 cmd[10];
    for(x=0;x<len;x++)               // Command / Data
    {
        cmd[x] = data[x];
    }
    
    /* Write len bytes to OSD9616 */

    return EZDSP5502_I2C_write( OSD9616_I2C_ADDR, cmd, len );
}



/*
 *
 *  Int16 printLetter(Uint16 l1,Uint16 l2,Uint16 l3,Uint16 l4)
 * 
 *      Send 4 bytes representing a Character
 *
 */
Int16 printLetter(Uint16 c4,Uint16 c3,Uint16 c2,Uint16 c1) //Exibe letra
{
    osd9616_send(0x40, c4);    // Column 4
    osd9616_send(0x40, c3);    // Column 3
    osd9616_send(0x40, c2);    // Column 2
    osd9616_send(0x40, c1);    // Column 1
    osd9616_send(0x40, 0x00);
    
    return 0;
}

/* Função não testada - evite utilizá-la
int showStat()
{

    // dados; tamanho; Endereço I2C ; read/write ; timeout; checkbus);
    int stat = 0;
    Uint16 cmd = 0;

    cmd = 0x00; //ler registrador do controlador
    //stat = EZDSP5502_I2C_read(cmd, 1, 0x3C, 0,3000,1);

    stat = I2C_read(cmd,1,0,0x3C,0,30,0);
    printf("\n stat %u\n", stat);
    return stat;

}*/


